export class LayoutConfig {
  sidebarExpanded?: boolean;
}
