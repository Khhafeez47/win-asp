﻿namespace win-asp-core-iis.Roles.Dto
{
    public class GetRolesInput
    {
        public string Permission { get; set; }
    }
}
