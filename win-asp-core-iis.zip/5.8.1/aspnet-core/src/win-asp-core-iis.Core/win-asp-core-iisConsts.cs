﻿namespace win-asp-core-iis
{
    public class win-asp-core-iisConsts
    {
        public const string LocalizationSourceName = "win-asp-core-iis";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
