﻿namespace win-asp-core-iis.Configuration
{
    public static class AppSettingNames
    {
        public const string UiTheme = "App.UiTheme";
    }
}
